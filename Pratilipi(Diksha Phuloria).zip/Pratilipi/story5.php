<?php

include('db.php');

$user=get_current_user();
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

$result=mysqli_query($db,$stmt);


?>



<?php  
  
session_start(); 
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 

<?php  
   
unset($_SESSION['views']);  
session_destroy(); 
  
 ?> 




<!DOCTYPE html>
<html>
<head>
	<title>The Golden Egg</title>
</head>
<body>
	<h1>The Golden Egg</h1>

<div class="block1">	
	<p>Once upon a time, a farmer had a goose that laid one golden egg every day. The egg provided enough money for the farmer and his wife to support their daily needs. The farmer and his wife continued to be happy for a long time.

	But, one day, the farmer thought to himself, “Why should we take just one egg a day? Why can’t we take them all at once and make a lot of money?” The farmer told his wife his idea, and she foolishly agreed.

	Then, the next day, as the goose laid its golden egg, the farmer was quick with a sharp knife. He killed the goose and cut its stomach open, in the hopes of finding all its golden eggs. But, as he opened the stomach, the only thing he found was guts and blood.

	The farmer quickly realized his foolish mistake and proceeded to cry over his lost resource. As the days went on, the farmer and his wife became poorer and poorer. How jinxed and how foolish they were.
	</p>

	<h2>MORAL</h2>
	<p>Never act before you think.</p>
</div>

<div class="views">
<h3>Total Views: <?php echo mysqli_num_rows($result);?></h3>

<h3>Active Now: <?php echo $msg?></h3>
</div>

</body>
<style type="text/css">
body{
		background: #557d5c fixed 100%;
		background-size: cover;
		color: black; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}

	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>