<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: index.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>


</head>
<body>

	<?php if(isset($_SESSION['success'])): ?>

		<div class="error success">
			<h3>
				<?php 

				echo $_SESSION['success'];
				unset($_SESSION['success']);

				?>
			</h3>
		</div>

	<?php endif?>


    <button id="logout"><a href="logout.php">&#8592;Logout</a></button>

<!-- logged in user information -->

<button id="hello">PROFILE</button>


<div class="hello">
	<div style="font-size: 40px; margin-top:50px;">HELLO !</div>

	<?php if(isset($_SESSION['Username'])): ?>
		<h1 style="font-family:'Tangerine'; font-weight: 600; ">Welcome <?php echo $_SESSION['Username']; ?></h1>

	<?php endif?>

</div>

<div class="stories">

	<h1>S T O R I E S</h1>
	
</div>

<div class="story-box">
	
	<div class="story">
		<h2>1. The Struggles of Our Life</h2>

		<a href="story1.php" target="blank">View</a>

	</div>

	
	<div class="story">
		<h2>2. The Boy Who Cried Wolf</h2>
		<a href="story2.php" target="blank">View</a>

	</div>

	

	<div class="story">

		<h2>3. The Bear and the Two Friends</h2>
		<a href="story3.php" target="blank">View</a>
	</div>

	

	<div class="story">
		<h2>4. The Proud Rose</h2>
		<a href="story4.php" target="blank">View</a>
	</div>

	

	<div class="story">
		
		<h2>5. The Golden Egg</h2>
		<a href="story5.php" target="blank">View</a>

	</div>

	
	<div class="story">
		
		<h2>6. The Needle Tree</h2>
		<a href="story6.php" target="blank">View</a>
	
	</div>


</div>


</body>
<style>
		body{
			background: url(book.jpg) fixed 100%;
			background-size: cover;
			justify-content: center;
			font-family: 'Playfair Display';
			font-size: 30px;

		}

		.story > a{
			
			color:teal;
			background:white;
			position: relative;
			bottom:10px;

		}




</style>

<script type="text/javascript">

	$(document).ready(function() {

		$('#hello').click(function() {
			$('.hello').fadeToggle('slow')

		});
		
	});
	
</script>

</html>