<?php

include('db.php');

$user=get_current_user();
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

$result=mysqli_query($db,$stmt);


?>


<?php  
  
session_start(); 
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 

<?php  
   
unset($_SESSION['views']);  
session_destroy(); 
  
 ?> 



<!DOCTYPE html>
<html>
<head>
	<title> The Needle Tree</title>
</head>
<body>

	<h1> The Needle Tree </h1>

<div class="block1">	
	<p>Once, there were two brothers who lived at the forest’s edge. The oldest brother was always unkind to his younger brother. The older brother took all the food and snatched all the good clothes.

	The oldest brother used to go into the forest in search of firewood to sell in the market. As he walked through the forest, he chopped off the branches of every tree, until he came upon a magical tree.

	The tree stopped him before he chopped its branches and said, ‘Oh, kind sir, please spare my branches. If you spare me, I will provide you with golden apples.’

	The oldest brother agreed but was feeling disappointed with how many apples the tree gave him.

	Overcome by greed, the brother threatened to cut the entire tree if it didn’t provide him with more apples. But, instead of giving more apples, the tree showered him with hundreds of tiny needles. The brother fell to the ground, crying in pain as the sun began to set.

	Soon, the younger brother became worried and went to search for his older brother. He searched until he found him at the trunk of the tree, lying in pain with hundreds of needles on his body.

	He rushed to him and started to painstakingly remove each needle with love. Once the needles were out, the oldest brother apologized for treating his younger brother so badly. The magical tree saw the change in the older brother’s heart and gifted them with all the golden apples they could need.
	</p>

	<h2>MORAL</h2>
	<p>It’s important to be kind, as it will always be rewarded.</p>
</div>

<div class="views">
<h3>Total Views: <?php echo mysqli_num_rows($result);?></h3>

<h3>Active Now: <?php echo $msg?></h3>
</div>
	

</body>

<style type="text/css">
body{
		background: black fixed 100%;
		background-size: cover;
		color: teal; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}

	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>