<?php

include('db.php');

$user=get_current_user();
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

 $result=mysqli_query($db,$stmt);


?>

<?php  
  
session_start(); 
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 

<?php  
   
unset($_SESSION['views']);  
session_destroy(); 
  
 ?> 


<!DOCTYPE html>
<html>
<head>
	<title>The Bear and the Two Friends</title>
</head>
<body>
	<h1>The Bear and the Two Friends</h1>

<div class="block1">	
	<p>
		One day, two friends were walking through the forest. They knew the forest was a dangerous place and that anything could happen. So, they promised to remain close to each other in case of any danger.

		All of a sudden, a big bear was approaching them. One of the friends quickly climbed a nearby tree, leaving the other friend behind.

		The other friend did not know how to climb, and instead, followed common sense. He laid down on the ground and remained there, breathless, pretending to be dead.

		The bear approached the friend lying on the ground. The animal started to smell his ear before slowly wandering off again because bears never touch those who are dead.

		Soon, the friend who hid in the tree came down. He asked his friend, “My dear friend, what secret did the bear whisper to you?” The friend replied, “The bear simply advised me never to believe a false friend.”


	</p>

	<h2>MORAL</h2>
	<p>A true friend will always support and stand by you in any situation.</p>
</div>

<div class="views">
<h3>Total Views: <?php echo mysqli_num_rows($result);?></h3>

<h3>Active Now: <?php echo $msg?></h3>
</div>
	


</body>

<style type="text/css">
	body{
		background: #ff8957 fixed 100%;
		background-size: cover;
		color: black; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}

	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>