<?php error_reporting(0);?>
<?php include('server.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">	
	
</head>
<body>

	<h1 style="color:italic; font-weight: 100; width: 100%; height: auto; background-color: black; margin-top: 0;">~ To view amazing stories you need to Login to your account ~</h1>
	

	<div class="block">
			
			<div class="sub1">

				<div class="welcome">  L O G I N  </div>

				<div class="form-box">
					<div class="button-box">
						<div id="btn"></div>
						<button type="button" class="toggle-btn" style="text-decoration: none;" >Login</button>

						<button type="button" class="toggle-btn"><a href="register.php" style="text-decoration: none; color:white;">Register</a></button>

					</div>

					<form class="form1" action="index.php" method="POST">
						
						<?php include('errors.php'); ?>

						<input type="text" id="username"  name="Username" placeholder="Username" required>

						<input type="password" id="password"  name="password" placeholder="Enter Password" required>

						<button type="submit" id="login_btn" name="login_user" style="margin-top: 50px;">Login</button>


						<h4 style="margin-top: 35px; font-weight: 200;">New User? Click on Register! </h4>
					</form>

				</div>

			</div>
		

		</div>

</body>
<style type="text/css">
	
</style>
</html>