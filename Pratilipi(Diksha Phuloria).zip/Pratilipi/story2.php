<?php

include('db.php');

$user=get_current_user();
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

 $result=mysqli_query($db,$stmt);


?>


<?php  
  
session_start(); 
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 

<?php  
   
unset($_SESSION['views']);  
session_destroy(); 
  
 ?> 



<!DOCTYPE html>
<html>
<head>
	<title>The Boy Who Cried Wolf</title>
</head>
<body>
	<h1>The Boy Who Cried Wolf</h1>

<div class="block1">
	<p>Once, there was a boy who became bored when he watched over the village sheep grazing on the hillside. To entertain himself, he sang out, “Wolf! Wolf! The wolf is chasing the sheep!”, When the villagers heard the cry, they came running up the hill to drive the wolf away. But, when they arrived, they saw no wolf. The boy was amused when seeing their angry faces.

	“Don’t scream wolf, boy,” warned the villagers, “when there is no wolf!” They angrily went back down the hill. Later, the shepherd boy cried out once again, “Wolf! Wolf! The wolf is chasing the sheep!” To his amusement, he looked on as the villagers came running up the hill to scare the wolf away. As they saw there was no wolf, they said strictly, “Save your frightened cry for when there really is a wolf! Don’t cry ‘wolf’ when there is no wolf!” But the boy grinned at their words while they walked grumbling down the hill once more.

	Later, the boy saw a real wolf sneaking around his flock. Alarmed, he jumped on his feet and cried out as loud as he could, “Wolf! Wolf!” But the villagers thought he was fooling them again, and so they didn’t come to help. At sunset, the villagers went looking for the boy who hadn’t returned with their sheep. When they went up the hill, they found him weeping.
      “There really was a wolf here! The flock is gone! I cried out, ‘Wolf!’ but you didn’t come,” he wailed.

	An old man went to comfort the boy. As he put his arm around him, he said, “Nobody believes a liar, even when he is telling the truth!”</p>

	<h2>MORAL</h2>
	<p>Lying breaks trust — even if you’re telling the truth, no one believes a liar.</p>

</div>

<div class="views">
<h3>Total Views: <?php echo mysqli_num_rows($result);?></h3>

<h3>Active Now: <?php echo $msg?></h3>
</div>
	

</body>
<style type="text/css">
	body{
		background: #54777d fixed 100%;
		background-size: cover;
		color: black; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}

	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>