<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: profile.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: profile.php");
}

?>


<?php

include('db.php');

$user=$_SESSION["Username"];
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

$result=mysqli_query($db,$stmt);
$row=mysqli_fetch_row($result)




?>



<?php  
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 

<!DOCTYPE html>
<html>
<head>
	<title> The Proud Rose</title>
</head>
<body>
	<h1>The Proud Rose</h1>

<div class="block1">	
	<p>Once upon a time, in a desert far away, there was a rose who was so proud of her beautiful looks. Her only complaint was growing next to an ugly cactus.

	Every day, the beautiful rose would insult and mock the cactus on his looks, all while the cactus remained quiet. All the other plants nearby tried to make the rose see sense, but she was too swayed by her own looks.

	One scorching summer, the desert became dry, and there was no water left for the plants. The rose quickly began to wilt. Her beautiful petals dried up, losing their lush color.

	Looking to the cactus, she saw a sparrow dip his beak into the cactus to drink some water. Though ashamed, the rose asked the cactus if she could have some water. The kind cactus readily agreed, helping them both through the tough summer, as friends.
	</p>

	<h2>MORAL</h2>
	<p>Never judge anyone by the way they look.</p>


</div>

<div class="views">
<h3>Total Views: <?php echo $row[0];?></h3>
<h3>Active Now: <?php echo $msg?></h3>
</div>
	

</body>
<style type="text/css">
body{
		background: #d8b5ff fixed 100%;
		background-size: cover;
		color: black; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}

	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>