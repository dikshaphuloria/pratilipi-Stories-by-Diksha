<?php error_reporting(0);?>
<?php include('server.php'); ?>


<!DOCTYPE html>
<html>
<head>
	<title>~ Register ~</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">
	


</head>
<body>

		<div class="block">
			
			<div class="sub1">

				<div class="welcome">  R E G I S T E R  </div>

				<div class="form-box">
					<div class="button-box">
						<div id="btn" style="left: 110px;"></div>
						<button type="button" class="toggle-btn" ><a href="index.php" style="text-decoration: none; color:white;">Login</a></button>

						<button type="button" class="toggle-btn" >Register</button>

					</div>

					<form class="form2" action="register.php" method="post">
						<?php include('errors.php'); ?>

						<input type="text" id="username" name="Username" placeholder="Username" >


						<input type="password" id="password1" name="password1" placeholder="Enter Password" >

						<input type="password" id="password2" name="password2" placeholder="Confirm Password" >

						
						<button type="submit" id="register_btn" name="register_user" style="margin-top: 50px; ">Register</button>
					</form>


				</div>

			</div>
		

		</div>
		
</body>



</html>