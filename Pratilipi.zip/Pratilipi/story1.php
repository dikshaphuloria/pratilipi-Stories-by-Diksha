<?php

session_start();

if(!isset($_SESSION['Username'])){

	$_SESSION['msg'] = "You must log in to view this page";
	header('location: profile.php');

}

if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION["Username"]);
	header("location: profile.php");
}

?>


<?php

include('db.php');

$user=$_SESSION["Username"];
$story= $_SERVER['REQUEST_URI'];

$Query= "SELECT * FROM countvisits WHERE storyName='$story' ";

$result = mysqli_query($db,$Query);

if($result->num_rows==0){

$insertQuery ="INSERT INTO countvisits (storyName,user) VALUES ('$story','$user')";

mysqli_query($db,$insertQuery);

}
else{

	$row = $result->fetch_assoc();

	if(!preg_match('/'.$user.'/i', $row['user'])){

		$newUser ="$row[user] $user";

		$updateQuery = "UPDATE countvisits SET user='$newUser', visits= visits+1 WHERE storyName='$story'";

		mysqli_query($db,$updateQuery);

	}
}


$stmt = "SELECT visits FROM countvisits WHERE storyName='$story'";

$result=mysqli_query($db,$stmt);
$row=mysqli_fetch_row($result)




?>



<?php  
   
if(isset($_SESSION['views'])) 
    $_SESSION['views'] = $_SESSION['views']+1; 
else
    $_SESSION['views']=1; 
   $msg= $_SESSION['views']; 
  
?> 




<!DOCTYPE html>
<html>
<head>
	<title>The Struggles of Our Life</title>

</head>
<body>
	
	<div style=" color: black; "><h1>The Struggles of Our Life</h1></div><div>



<div class="block1">
	<p >Once upon a time, a daughter complained to her father that her life was miserable and that she didn’t know how she was going to make it. She was tired of fighting and struggling all the time. It seemed just as one problem was solved, another one soon followed. Her father, a chef, took her to the kitchen. He filled three pots with water and placed each on a high fire.

	Once the three pots began to boil, he placed potatoes in one pot, eggs in the second pot and ground coffee beans in the third pot. He then let them sit and boil, without saying a word to his daughter. The daughter impatiently waited, wondering what he was doing. After twenty minutes he turned off the burners. He took the potatoes out of the pot and placed them in a bowl. He pulled the eggs out and placed them in a bowl. He then ladled the coffee out and placed it in a cup.

	Turning to her, he asked. “Daughter, what do you see?” “Potatoes, eggs and coffee,” she hastily replied.

	“Look closer”, he said, “and touch the potatoes.” She did and noted that they were soft.

	He then asked her to take an egg and break it. After pulling off the shell, she observed the hard-boiled egg.

	Finally, he asked her to sip the coffee. Its rich aroma brought a smile to her face.

	“Father, what does this mean?” she asked.

	He then explained that the potatoes, the eggs and coffee beans had each faced the same adversity-the boiling water. However, each one reacted differently. The potato went in strong, hard and unrelenting, but in boiling water, it became soft and weak. The egg was fragile, with the thin outer shell protecting its liquid interior until it was put in the boiling water. Then the inside of the egg became hard. However, the ground coffee beans were unique. After they were exposed to the boiling water, they changed the water and created something new.

	“Which one are you?” he asked his daughter. “When adversity knocks on your door, how do you respond? Are you a potato, an egg, or a coffee bean?”

</p>

<h2>MORAL</h2>

	<p>In life, things happen around us, things happen to us, but the only thing that truly matters is how you choose to react to it and what you make out of it. Life is all about leaning, adopting and converting all the struggles that we experience into something positive.</p>

</div>

<div class="views">
<h3>Total Views: <?php echo $row[0];?></h3>

<h3>Active Now: <?php echo $msg?></h3>
</div>
	

</body>

<style>
	body{
		background:#fcba03 fixed 100%;
		background-size: cover;
		color: black; 
		font-size:30px; 
		justify-content: center;
		align-items: center;
	}

	.block1{
	background-color:#fefbd8;
	width: 80%;
	border:50px solid transparent;
	margin:20px auto;
	color: black;
	font-size: 25px;
	font-family: sans-serif; 
	font-weight: 600;
	}


	.views{
		justify-content: center;
		text-align: center;
	}

	.views> h3{
		width:200px;
		height: 100px;
		font-weight: 100;
		padding: 10px 10px;
		box-shadow: 0 0 20px 9px #eee260;
		border-radius: 20px;
		background-color: black;
		color: white;
		margin:70px auto;
	}
</style>
</html>